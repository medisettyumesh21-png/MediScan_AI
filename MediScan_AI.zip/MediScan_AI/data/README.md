# data/

The app loads the **Wisconsin Diagnostic Breast Cancer** dataset directly from scikit-learn
(`sklearn.datasets.load_breast_cancer`), so no dataset file is required here.

* `sample_upload.csv` - 10 public records from the dataset's held-out test split with anonymous
  `demo-###` case IDs. Use it to try the **Dataset Explorer -> Batch upload** feature.

Do **not** add real patient data to this repository.
