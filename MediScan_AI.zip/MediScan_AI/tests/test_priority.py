"""Tests for the illustrative review-priority rules."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.priority import HIGH, MEDIUM, ROUTINE, priority_for  # noqa: E402


class PriorityTests(unittest.TestCase):
    def test_categories_and_boundaries(self):
        self.assertIs(priority_for(0.0), ROUTINE)
        self.assertIs(priority_for(0.399), ROUTINE)
        self.assertIs(priority_for(0.40), MEDIUM)
        self.assertIs(priority_for(0.799), MEDIUM)
        self.assertIs(priority_for(0.80), HIGH)
        self.assertIs(priority_for(1.0), HIGH)

    def test_invalid_probabilities_rejected(self):
        for bad in (-0.1, 1.1, float("nan"), None):
            with self.assertRaises(ValueError):
                priority_for(bad)

    def test_every_level_recommends_human_review(self):
        for level in (HIGH, MEDIUM, ROUTINE):
            self.assertIn("clinician", level.action)


if __name__ == "__main__":
    unittest.main()
