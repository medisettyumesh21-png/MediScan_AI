"""Tests for CSV upload validation and report generation."""
import io
import os
import sys
import unittest

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from model import FEATURE_NAMES, train_model  # noqa: E402
from utils.analysis import analyze_records, report_csv, sample_csv_bytes  # noqa: E402
from utils.data_utils import MAX_ROWS, template_csv_bytes, validate_uploaded_csv  # noqa: E402


def to_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode("utf-8")


class ValidationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.bundle = train_model()
        cls.good = pd.read_csv(io.BytesIO(sample_csv_bytes(cls.bundle, 8)))

    def test_valid_file(self):
        r = validate_uploaded_csv(to_bytes(self.good))
        self.assertTrue(r.ok)
        self.assertEqual((r.rows_total, r.rows_valid), (8, 8))
        self.assertEqual(list(r.features.columns), FEATURE_NAMES)

    def test_empty_and_header_only(self):
        self.assertFalse(validate_uploaded_csv(b"").ok)
        r = validate_uploaded_csv(template_csv_bytes())
        self.assertFalse(r.ok)
        self.assertIn("no data rows", r.errors[0])

    def test_missing_columns_message_is_helpful(self):
        r = validate_uploaded_csv(to_bytes(self.good.drop(columns=["mean area", "worst radius"])))
        self.assertFalse(r.ok)
        self.assertIn("2 of the 30", r.errors[0])
        self.assertIn("mean area", r.errors[0])
        self.assertIn("template", r.errors[0])

    def test_non_numeric_missing_and_negative_rows_excluded(self):
        bad = self.good.copy().astype(object)
        bad.loc[0, "mean radius"] = "abc"
        bad.loc[1, "mean area"] = -5
        bad.loc[2, "mean texture"] = None
        r = validate_uploaded_csv(to_bytes(bad))
        self.assertTrue(r.ok)
        self.assertEqual(r.rows_valid, 5)
        self.assertEqual(r.rows_excluded, 3)
        self.assertEqual(len(r.warnings) >= 3, True)
        self.assertEqual(len(r.features), len(r.case_ids))

    def test_all_rows_invalid(self):
        bad = self.good.copy().astype(object)
        bad["mean radius"] = "x"
        r = validate_uploaded_csv(to_bytes(bad))
        self.assertFalse(r.ok)
        self.assertEqual(r.rows_valid, 0)

    def test_infinite_values_rejected(self):
        bad = self.good.copy()
        bad.loc[0, "mean radius"] = float("inf")
        r = validate_uploaded_csv(to_bytes(bad))
        self.assertEqual(r.rows_valid, 7)

    def test_identifier_columns_rejected(self):
        for col in ("patient_name", "Patient ID", "date_of_birth", "email", "SSN", "home address", "phone"):
            df = self.good.copy()
            df[col] = "x"
            r = validate_uploaded_csv(to_bytes(df))
            self.assertFalse(r.ok, col)
            self.assertIn("personal identifiers", r.errors[0])

    def test_feature_names_not_flagged_as_identifiers(self):
        self.assertTrue(validate_uploaded_csv(to_bytes(self.good)).ok)

    def test_kaggle_style_column_names_accepted(self):
        kag = {}
        for f in FEATURE_NAMES:
            if f.startswith("mean "):
                kag[f] = f[5:].replace(" ", "_") + "_mean"
            elif f.startswith("worst "):
                kag[f] = f[6:].replace(" ", "_") + "_worst"
            else:
                kag[f] = f[:-6].replace(" ", "_") + "_se"
        df = self.good.rename(columns=kag)
        r = validate_uploaded_csv(to_bytes(df))
        self.assertTrue(r.ok, r.errors)
        self.assertEqual(list(r.features.columns), FEATURE_NAMES)

    def test_extra_columns_ignored_with_warning(self):
        df = self.good.copy()
        df["diagnosis"] = "M"
        r = validate_uploaded_csv(to_bytes(df))
        self.assertTrue(r.ok)
        self.assertTrue(any("diagnosis" in w for w in r.warnings))

    def test_bad_file_types(self):
        self.assertFalse(validate_uploaded_csv(b"PK\x03\x04\x00\x00\xff\xfe").ok)           # binary / not UTF-8
        self.assertFalse(validate_uploaded_csv(b"just some text without commas").ok)
        semi = to_bytes(self.good).replace(b",", b";")
        r = validate_uploaded_csv(semi)
        self.assertFalse(r.ok)
        self.assertIn("semicolon", r.errors[0])

    def test_row_limit(self):
        big = pd.concat([self.good] * (MAX_ROWS // len(self.good) + 2), ignore_index=True)
        r = validate_uploaded_csv(to_bytes(big))
        self.assertFalse(r.ok)
        self.assertIn("limit", r.errors[0])

    def test_analysis_and_report(self):
        r = validate_uploaded_csv(to_bytes(self.good))
        res = analyze_records(self.bundle, r.features, r.case_ids.to_numpy())
        self.assertEqual(len(res), 8)
        self.assertTrue(((res["p_malignant"] >= 0) & (res["p_malignant"] <= 1)).all())
        rep = pd.read_csv(io.BytesIO(report_csv(res)))
        self.assertIn("note", rep.columns)
        self.assertEqual(len(rep), 8)

    def test_report_neutralises_spreadsheet_formulas(self):
        df = self.good.copy()
        df["case_id"] = ["=1+1"] + list(df["case_id"][1:])
        r = validate_uploaded_csv(to_bytes(df))
        res = analyze_records(self.bundle, r.features, r.case_ids.to_numpy())
        self.assertTrue(report_csv(res).decode().splitlines()[1].startswith("'=1+1"))

    def test_out_of_range_values_are_flagged(self):
        df = self.good.copy()
        df.loc[0, "mean area"] = 99999.0
        r = validate_uploaded_csv(to_bytes(df))
        res = analyze_records(self.bundle, r.features, r.case_ids.to_numpy())
        self.assertGreaterEqual(int(res["features_outside_training_range"].iloc[0]), 1)


if __name__ == "__main__":
    unittest.main()
