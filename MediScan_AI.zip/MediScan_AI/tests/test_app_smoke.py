"""
Streamlit smoke test: starts app.py headlessly and opens every page.
Skipped automatically if Streamlit is not installed or is too old (needs >= 1.28).
"""
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

try:
    from streamlit.testing.v1 import AppTest
    HAVE_APPTEST = True
except Exception:  # streamlit missing or too old
    HAVE_APPTEST = False


@unittest.skipUnless(HAVE_APPTEST, "streamlit (>=1.28) is not installed")
class AppSmokeTests(unittest.TestCase):
    PAGES = ["🏠  Home Dashboard", "🔬  Case Analysis", "🗂️  Dataset Explorer", "🧠  AI Model Insights", "🛡️  About & Safety"]

    def test_every_page_renders_without_exceptions(self):
        at = AppTest.from_file(os.path.join(ROOT, "app.py"), default_timeout=90)
        at.run()
        self.assertFalse(at.exception, [e.value for e in at.exception])
        for page in self.PAGES:
            at.session_state["nav_page"] = page
            at.run()
            self.assertFalse(at.exception, f"{page}: {[e.value for e in at.exception]}")


if __name__ == "__main__":
    unittest.main()
