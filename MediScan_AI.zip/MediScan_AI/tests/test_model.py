"""Tests for the machine-learning core (model.py). Run: python -m unittest discover -s tests -v"""
import math
import os
import sys
import unittest

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from model import BENIGN, FEATURE_NAMES, MALIGNANT, explain_case, malignant_probability, train_model  # noqa: E402


class ModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.b = train_model()

    def test_dataset_loaded_and_clean(self):
        q = self.b.quality
        self.assertEqual((q["n_records"], q["n_features"]), (569, 30))
        self.assertEqual(q["missing_values_found"], 0)
        self.assertEqual(len(FEATURE_NAMES), 30)

    def test_split_has_no_overlap_and_covers_all_rows(self):
        tr, te = set(self.b.train_index), set(self.b.test_index)
        self.assertFalse(tr & te)
        self.assertEqual(len(tr) + len(te), 569)

    def test_scaler_fitted_on_training_data_only(self):
        """No leakage: scaler statistics must equal the TRAINING means, not the full-data means."""
        X = self.b.data[FEATURE_NAMES]
        train_means = X.loc[self.b.train_index].mean()
        full_means = X.mean()
        np.testing.assert_allclose(self.b.train_mean.to_numpy(), train_means.to_numpy(), rtol=1e-9)
        self.assertFalse(np.allclose(self.b.train_mean.to_numpy(), full_means.to_numpy(), rtol=1e-12))

    def test_reproducible(self):
        b2 = train_model()
        self.assertEqual(self.b.metrics, b2.metrics)
        np.testing.assert_array_equal(self.b.coefficients["coefficient"].to_numpy(),
                                      b2.coefficients["coefficient"].to_numpy())

    def test_metrics_in_sensible_range(self):
        m = self.b.metrics
        for k in ("accuracy", "precision", "recall", "f1", "roc_auc", "specificity"):
            self.assertTrue(0.0 <= m[k] <= 1.0, k)
        self.assertGreater(m["accuracy"], 0.90)   # well-known easy dataset
        self.assertGreater(m["roc_auc"], 0.95)
        self.assertEqual(int(self.b.confusion.sum()), m["n_test"])

    def test_probabilities_valid(self):
        X = self.b.data[FEATURE_NAMES]
        p = malignant_probability(self.b.pipeline, X)
        self.assertTrue(np.all((p >= 0) & (p <= 1)))
        proba = self.b.pipeline.predict_proba(X)
        np.testing.assert_allclose(proba.sum(axis=1), 1.0)
        # malignant probability must agree with the class-0 column
        np.testing.assert_allclose(p, proba[:, list(self.b.pipeline.classes_).index(MALIGNANT)])

    def test_malignant_records_score_higher_on_average(self):
        X = self.b.data[FEATURE_NAMES]
        p = malignant_probability(self.b.pipeline, X)
        t = self.b.data["target"].to_numpy()
        self.assertGreater(p[t == MALIGNANT].mean(), p[t == BENIGN].mean() + 0.5)

    def test_explanation_adds_up_to_model_log_odds(self):
        """Contributions + intercept term must reproduce the model's malignant log-odds exactly."""
        clf = self.b.pipeline.named_steps["clf"]
        for idx in (0, 100, 300, 568):
            row = self.b.data.loc[idx, FEATURE_NAMES]
            contrib = explain_case(self.b, row)
            logit = contrib["contribution"].sum() - clf.intercept_[0]
            p_expected = float(malignant_probability(self.b.pipeline, row.to_frame().T.astype(float))[0])
            self.assertAlmostEqual(1 / (1 + math.exp(-logit)), p_expected, places=9)

    def test_explanation_sorted_by_importance(self):
        c = explain_case(self.b, self.b.data.loc[5, FEATURE_NAMES])
        self.assertTrue((c["abs_contribution"].diff().dropna() <= 1e-12).all())
        self.assertEqual(len(c), 30)


if __name__ == "__main__":
    unittest.main()
