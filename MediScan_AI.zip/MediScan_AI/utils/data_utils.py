"""
data_utils.py - validation of user-uploaded CSV files.

Design goals
------------
* Accept only files that match the model's 30-feature schema.
* Give plain-English error messages a beginner can act on.
* Refuse files that look like they contain identifiable patient information.
* Never write uploaded data to disk - everything stays in memory.
"""
from __future__ import annotations

import io
import re
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from model import FEATURE_NAMES

MAX_UPLOAD_MB = 5
MAX_ROWS = 5000

# Column names that suggest personal data -> the whole file is rejected.
IDENTIFIER_TOKENS = {
    "name", "surname", "patient", "ssn", "dob", "birth", "birthdate", "address",
    "phone", "telephone", "email", "mrn", "passport", "aadhaar", "aadhar",
    "insurance", "zip", "postcode", "pincode", "nric",
}
# Optional column that may hold an anonymous label for each row.
CASE_ID_COLUMNS = ["case id", "id", "sample id", "record id", "case"]


def _norm(col: object) -> str:
    """Normalise a column name: lower-case, underscores/hyphens -> single spaces."""
    return re.sub(r"[\s_\-]+", " ", str(col).strip().lower())


def _build_alias_map() -> dict[str, str]:
    """Map accepted column spellings to the canonical scikit-learn names.

    Accepts e.g. 'mean radius', 'mean_radius', 'radius_mean' (Kaggle style),
    'radius_se' / 'radius error', 'radius_worst' / 'worst radius'.
    """
    aliases: dict[str, str] = {}
    for feat in FEATURE_NAMES:
        aliases[_norm(feat)] = feat
        if feat.startswith("mean "):
            base, stat = feat[5:], "mean"
        elif feat.startswith("worst "):
            base, stat = feat[6:], "worst"
        elif feat.endswith(" error"):
            base, stat = feat[:-6], "se"
        else:
            continue
        aliases[_norm(f"{base} {stat}")] = feat
    return aliases


ALIAS_MAP = _build_alias_map()


@dataclass
class ValidationResult:
    ok: bool
    features: pd.DataFrame | None = None      # valid rows, canonical columns in model order
    case_ids: pd.Series | None = None         # label for every valid row
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    rows_total: int = 0
    rows_valid: int = 0

    @property
    def rows_excluded(self) -> int:
        return self.rows_total - self.rows_valid


def _fail(msg: str, rows_total: int = 0) -> ValidationResult:
    return ValidationResult(ok=False, errors=[msg], rows_total=rows_total)


def _row_list(mask: pd.Series, limit: int = 10) -> str:
    rows = [str(i + 1) for i in np.flatnonzero(mask.to_numpy())]
    shown = ", ".join(rows[:limit])
    return shown + (f" ... (+{len(rows) - limit} more)" if len(rows) > limit else "")


def validate_uploaded_csv(raw: bytes) -> ValidationResult:
    """Validate raw CSV bytes against the expected feature schema."""
    # ---- file-level checks ------------------------------------------------
    if not raw:
        return _fail("The file is empty. Please upload a CSV that contains a header row and data rows.")
    if len(raw) > MAX_UPLOAD_MB * 1024 * 1024:
        return _fail(f"The file is larger than {MAX_UPLOAD_MB} MB. Please upload a smaller file.")
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        return _fail("The file is not plain UTF-8 text. Please save it as 'CSV UTF-8 (comma delimited)' and try again.")
    if "\x00" in text:
        return _fail("The file looks like a binary file, not a CSV. Please export it as a .csv text file.")

    try:
        df = pd.read_csv(io.StringIO(text))
    except pd.errors.EmptyDataError:
        return _fail("The file has no readable columns. Please check that the first row contains column names.")
    except pd.errors.ParserError as exc:
        return _fail(f"The CSV could not be parsed ({exc}). Please check for stray quotes or uneven rows.")
    except Exception as exc:  # defensive: never crash the UI on a bad upload
        return _fail(f"The file could not be read as a CSV ({type(exc).__name__}).")

    if len(df) == 0:
        return _fail("The file has a header but no data rows.")
    if len(df) > MAX_ROWS:
        return _fail(f"The file has {len(df):,} rows; the limit is {MAX_ROWS:,} rows per upload.")

    n_rows = len(df)
    errors: list[str] = []
    warnings: list[str] = []

    # ---- privacy check: refuse identifiable-looking columns ---------------
    risky = [c for c in df.columns if set(_norm(c).split(" ")) & IDENTIFIER_TOKENS]
    if risky:
        return _fail(
            "Possible personal identifiers found in column(s): "
            + ", ".join(f"'{c}'" for c in risky[:5])
            + ". For privacy, MediScan AI does not accept files with names, patient IDs, contact details or dates of birth. "
              "Remove those columns (use only public, synthetic or fully anonymised data) and upload again.",
            n_rows,
        )

    # ---- column mapping -----------------------------------------------------
    rename, case_col = {}, None
    for col in df.columns:
        key = _norm(col)
        if key in ALIAS_MAP:
            rename[col] = ALIAS_MAP[key]
        elif case_col is None and key in CASE_ID_COLUMNS:
            case_col = col
    df_feat = df.rename(columns=rename)

    dup = df_feat.columns[df_feat.columns.duplicated()].tolist()
    dup = [d for d in dup if d in FEATURE_NAMES]
    if dup:
        return _fail("Some feature columns appear more than once: " + ", ".join(sorted(set(dup))[:5]) + ".", n_rows)

    missing_cols = [f for f in FEATURE_NAMES if f not in df_feat.columns]
    if missing_cols:
        hint = ""
        if df.shape[1] == 1 and ";" in str(df.columns[0]):
            hint = " Your file seems to use semicolons as separators - please save it with commas."
        return _fail(
            f"{len(missing_cols)} of the {len(FEATURE_NAMES)} required columns are missing, e.g. "
            + ", ".join(f"'{c}'" for c in missing_cols[:5])
            + ("..." if len(missing_cols) > 5 else "")
            + "." + hint + " Download the CSV template on this page to see the exact column names.",
            n_rows,
        )

    used = set(rename) | ({case_col} if case_col is not None else set())
    extra = [str(c) for c in df.columns if c not in used]
    if extra:
        warnings.append("These extra columns were ignored: " + ", ".join(extra[:8]) + ("..." if len(extra) > 8 else "") + ".")

    # ---- value checks -------------------------------------------------------
    raw_feats = df_feat[FEATURE_NAMES]
    numeric = raw_feats.apply(pd.to_numeric, errors="coerce")
    is_missing = raw_feats.isna()
    is_text = numeric.isna() & ~is_missing                       # present but not a number
    is_bad_range = (numeric < 0) | np.isinf(numeric)             # negative or infinite

    bad_missing = is_missing.any(axis=1)
    bad_text = is_text.any(axis=1)
    bad_range = is_bad_range.any(axis=1)
    bad_row = bad_missing | bad_text | bad_range

    if bad_missing.any():
        warnings.append(f"{int(bad_missing.sum())} row(s) have missing values and were excluded (data row numbers: {_row_list(bad_missing)}).")
    if bad_text.any():
        warnings.append(f"{int(bad_text.sum())} row(s) contain non-numeric text in a feature column and were excluded (rows: {_row_list(bad_text)}).")
    if bad_range.any():
        warnings.append(f"{int(bad_range.sum())} row(s) contain negative or infinite values, which are not valid measurements, and were excluded (rows: {_row_list(bad_range)}).")

    valid = ~bad_row
    if not valid.any():
        return ValidationResult(
            ok=False, rows_total=n_rows, rows_valid=0, warnings=warnings,
            errors=["No valid rows remain after checking the data. Please fix the problems listed below and re-upload."],
        )

    # ---- case labels ----------------------------------------------------------
    if case_col is not None:
        ids = df[case_col].astype(str).str.strip()
        warnings.append(f"Column '{case_col}' is used only as a row label. Make sure it is an anonymous code, not a real patient identifier.")
    else:
        ids = pd.Series([str(i + 1) for i in range(n_rows)], index=df.index)

    features = numeric.loc[valid, FEATURE_NAMES].astype(float)
    features.columns = list(FEATURE_NAMES)      # plain Python str names (scikit-learn requires this)

    return ValidationResult(
        ok=True,
        features=features,
        case_ids=ids.loc[valid],
        warnings=warnings,
        rows_total=n_rows,
        rows_valid=int(valid.sum()),
    )


def template_csv_bytes() -> bytes:
    """A header-only CSV with the exact column names the app expects."""
    return (",".join(["case_id"] + FEATURE_NAMES) + "\n").encode("utf-8")
