"""
priority.py - ILLUSTRATIVE review-priority categories.

The thresholds below are teaching values chosen for this prototype. They are
NOT clinically validated and must not be used to triage real patients.
Every category - including "Routine" - still requires human review.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

HIGH_THRESHOLD = 0.80     # P(malignant) >= 0.80  -> Priority 1
MEDIUM_THRESHOLD = 0.40   # 0.40 <= P(malignant) < 0.80 -> Priority 2


@dataclass(frozen=True)
class PriorityLevel:
    key: str
    label: str
    color: str          # accent colour used in the UI
    action: str         # short recommendation shown to the reviewer


HIGH = PriorityLevel(
    "high", "Priority 1 - High", "#D1495B",
    "Expedite review by a qualified clinician.",
)
MEDIUM = PriorityLevel(
    "medium", "Priority 2 - Medium", "#E0A030",
    "Schedule a prompt review by a qualified clinician.",
)
ROUTINE = PriorityLevel(
    "routine", "Priority 3 - Routine", "#0FA3A3",
    "Include in routine clinician review; a low score does not rule out disease.",
)

PRIORITY_ORDER = [HIGH.label, MEDIUM.label, ROUTINE.label]
PRIORITY_COLORS = {p.label: p.color for p in (HIGH, MEDIUM, ROUTINE)}


def priority_for(p_malignant: float) -> PriorityLevel:
    """Map a model-estimated malignant probability (0-1) to a review-priority level."""
    if p_malignant is None or (isinstance(p_malignant, float) and math.isnan(p_malignant)):
        raise ValueError("Probability is missing (NaN).")
    if not 0.0 <= float(p_malignant) <= 1.0:
        raise ValueError(f"Probability must be between 0 and 1, got {p_malignant!r}.")
    if p_malignant >= HIGH_THRESHOLD:
        return HIGH
    if p_malignant >= MEDIUM_THRESHOLD:
        return MEDIUM
    return ROUTINE
