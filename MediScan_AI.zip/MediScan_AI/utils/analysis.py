"""
analysis.py - turn model output into review tables and downloadable CSV reports.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from model import ModelBundle, malignant_probability
from utils.priority import priority_for

DISCLAIMER = "Decision-support estimate only - not a diagnosis. Requires review by a qualified clinician."


def analyze_records(bundle: ModelBundle, X: pd.DataFrame, case_ids=None) -> pd.DataFrame:
    """Score records and attach illustrative review-priority categories.

    ``features_outside_training_range`` counts features whose value lies outside
    the min-max range seen in training - a hint that the estimate may be unreliable.
    """
    X = X[bundle.feature_names]
    p_mal = malignant_probability(bundle.pipeline, X)
    levels = [priority_for(float(p)) for p in p_mal]
    outside = ((X < bundle.train_min) | (X > bundle.train_max)).sum(axis=1).to_numpy()
    ids = X.index + 1 if case_ids is None else case_ids
    return pd.DataFrame(
        {
            "case_id": np.asarray(ids),
            "p_malignant": p_mal,
            "p_benign": 1.0 - p_mal,
            "model_prediction": np.where(p_mal >= 0.5, "Malignant", "Benign"),
            "review_priority": [lv.label for lv in levels],
            "recommendation": [lv.action for lv in levels],
            "features_outside_training_range": outside,
        },
        index=X.index,
    )


def _csv_safe(value) -> str:
    """Stop spreadsheet apps from running user text as a formula (CSV injection)."""
    s = str(value)
    return "'" + s if s[:1] in ("=", "+", "-", "@", "\t", "\r") else s


def report_csv(results: pd.DataFrame) -> bytes:
    """Build a downloadable CSV report (probabilities as percentages + disclaimer)."""
    out = pd.DataFrame(
        {
            "case_id": [_csv_safe(c) for c in results["case_id"]],
            "malignant_probability_pct": (results["p_malignant"] * 100).round(1),
            "benign_probability_pct": (results["p_benign"] * 100).round(1),
            "model_prediction": results["model_prediction"],
            "review_priority": results["review_priority"],
            "recommendation": results["recommendation"],
            "features_outside_training_range": results["features_outside_training_range"],
            "note": DISCLAIMER,
        }
    )
    return out.to_csv(index=False).encode("utf-8")


def sample_csv_bytes(bundle: ModelBundle, n: int = 10) -> bytes:
    """Example upload: the first ``n`` held-out public WDBC records with anonymous case IDs."""
    idx = bundle.test_index[:n]
    sample = bundle.data.loc[idx, bundle.feature_names].copy()
    sample.insert(0, "case_id", [f"demo-{i + 1:03d}" for i in idx])
    return sample.to_csv(index=False).encode("utf-8")
