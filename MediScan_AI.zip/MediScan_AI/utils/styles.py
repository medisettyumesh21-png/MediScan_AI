"""
styles.py - custom CSS and small HTML helpers for the MediScan AI look & feel.

Palette: navy #0B2545, blue #1D4E89, light blue #A9D6E5, teal #0FA3A3, soft grey #F4F7FB.
NOTE: HTML snippets are built WITHOUT leading indentation, otherwise Markdown would
treat them as code blocks.
"""
from __future__ import annotations

import html

CSS = """
<style>
:root { --navy:#0B2545; --blue:#1D4E89; --light:#A9D6E5; --teal:#0FA3A3; --grey:#F4F7FB; --line:#DCE5EF; }
.stApp { background: var(--grey); }
.block-container { padding-top: 1.6rem; padding-bottom: 3rem; max-width: 1240px; }
#MainMenu, footer { visibility: hidden; }

/* Sidebar */
[data-testid="stSidebar"] { background: linear-gradient(180deg, #0B2545 0%, #13315C 100%); }
[data-testid="stSidebar"] * { color: #E6EEF7; }
[data-testid="stSidebar"] hr { border-color: rgba(169,214,229,.25); }

/* Headings */
h1, h2, h3 { color: var(--navy); letter-spacing: -0.01em; }

/* Page header */
.ms-header { display:flex; align-items:center; gap:14px; margin-bottom: .6rem; }
.ms-header img { width:52px; height:52px; }
.ms-title { font-size:1.9rem; font-weight:750; color:var(--navy); line-height:1.15; margin:0; }
.ms-sub { color:#4A5E78; font-size:.98rem; margin:2px 0 0 0; }

/* Cards */
.ms-card { background:#fff; border:1px solid var(--line); border-top:4px solid var(--teal);
  border-radius:14px; padding:16px 18px; box-shadow:0 1px 3px rgba(11,37,69,.06); height:100%; }
.ms-card-label { font-size:.78rem; text-transform:uppercase; letter-spacing:.06em; color:#5B6F89; font-weight:650; }
.ms-card-value { font-size:1.9rem; font-weight:750; color:var(--navy); margin-top:2px; }
.ms-card-sub { font-size:.82rem; color:#6B7C93; margin-top:2px; }
.ms-panel { background:#fff; border:1px solid var(--line); border-radius:14px; padding:18px 22px;
  box-shadow:0 1px 3px rgba(11,37,69,.06); margin-bottom:1rem; }
.ms-panel h4 { margin-top:0; color:var(--navy); }

/* Banners & badges */
.ms-banner { border-radius:12px; padding:12px 16px; margin:.6rem 0 1rem 0; font-size:.93rem; border:1px solid; }
.ms-banner.info { background:#E8F3FA; border-color:#BBD9EC; color:#0B2545; }
.ms-banner.warn { background:#FFF6E3; border-color:#F2D9A0; color:#5C4300; }
.ms-banner.safe { background:#E4F6F5; border-color:#A8DEDB; color:#075656; }
.ms-badge { display:inline-block; padding:5px 14px; border-radius:999px; color:#fff; font-weight:650; font-size:.92rem; }

/* Sidebar brand */
.ms-brand { display:flex; align-items:center; gap:10px; margin-bottom:.2rem; }
.ms-brand img { width:38px; height:38px; }
.ms-brand b { font-size:1.2rem; color:#fff; }
.ms-side-note { font-size:.76rem; line-height:1.35; opacity:.85; }

/* Mobile */
@media (max-width: 640px) {
  .block-container { padding: 1rem .8rem 2rem .8rem; }
  .ms-title { font-size:1.4rem; }
  .ms-card-value { font-size:1.5rem; }
  .ms-header img { width:40px; height:40px; }
}
</style>
"""


def metric_card(label: str, value: str, sub: str = "", accent: str = "#0FA3A3") -> str:
    return (
        f'<div class="ms-card" style="border-top-color:{accent}">'
        f'<div class="ms-card-label">{html.escape(label)}</div>'
        f'<div class="ms-card-value">{html.escape(value)}</div>'
        f'<div class="ms-card-sub">{html.escape(sub)}</div></div>'
    )


def banner(text: str, kind: str = "info") -> str:
    """kind: 'info' | 'warn' | 'safe'.  ``text`` may contain simple inline HTML (trusted, built by us)."""
    return f'<div class="ms-banner {kind}">{text}</div>'


def badge(label: str, color: str) -> str:
    return f'<span class="ms-badge" style="background:{color}">{html.escape(label)}</span>'
