"""
charts.py - Plotly figure builders (each function returns a plotly Figure).

Keeping chart code here keeps app.py short and readable.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go

from utils.priority import HIGH_THRESHOLD, MEDIUM_THRESHOLD, PRIORITY_COLORS, PRIORITY_ORDER

NAVY = "#0B2545"
BLUE = "#1D4E89"
LIGHT_BLUE = "#A9D6E5"
TEAL = "#0FA3A3"
RED = "#D1495B"
AMBER = "#E0A030"
GREY = "#8A97A8"
FONT = "Inter, Segoe UI, Helvetica, Arial, sans-serif"

CLASS_COLORS = {"Malignant": RED, "Benign": TEAL}


def _style(fig: go.Figure, title: str | None = None, height: int = 360) -> go.Figure:
    """Apply the shared MediScan look to a figure."""
    layout = dict(
        template="plotly_white",
        height=height,
        margin=dict(l=20, r=20, t=55 if title else 20, b=30),
        font=dict(family=FONT, color=NAVY, size=13),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        legend=dict(orientation="h", yanchor="bottom", y=-0.25, xanchor="center", x=0.5),
    )
    if title:
        layout["title"] = dict(text=title, x=0.0, xanchor="left", font=dict(size=16, color=NAVY))
    fig.update_layout(**layout)
    return fig


def distribution_donut(counts: dict[str, int], title: str = "Dataset class distribution") -> go.Figure:
    labels = list(counts.keys())
    fig = go.Figure(
        go.Pie(
            labels=labels,
            values=[counts[k] for k in labels],
            hole=0.62,
            marker=dict(colors=[CLASS_COLORS.get(k, BLUE) for k in labels], line=dict(color="white", width=2)),
            textinfo="label+percent",
            sort=False,
        )
    )
    return _style(fig, title, 340)


def metrics_bar(metrics: dict, title: str = "Test-set performance") -> go.Figure:
    names = ["Accuracy", "Precision", "Recall", "F1-score", "ROC-AUC"]
    vals = [metrics["accuracy"], metrics["precision"], metrics["recall"], metrics["f1"], metrics["roc_auc"]]
    fig = go.Figure(
        go.Bar(x=names, y=vals, marker_color=[BLUE, TEAL, TEAL, BLUE, NAVY],
               text=[f"{v:.3f}" for v in vals], textposition="outside")
    )
    fig.update_yaxes(range=[0, 1.1], title="Score")
    return _style(fig, title, 340)


def confusion_matrix_fig(cm: np.ndarray, title: str = "Confusion matrix (test set)") -> go.Figure:
    x = ["Predicted malignant", "Predicted benign"]
    y = ["Actual malignant", "Actual benign"]
    fig = go.Figure(
        go.Heatmap(z=cm, x=x, y=y, colorscale=[[0, "#EAF4FB"], [1, BLUE]], showscale=False,
                   hovertemplate="%{y} / %{x}: %{z}<extra></extra>")
    )
    top = float(np.max(cm)) or 1.0
    for i in range(2):
        for j in range(2):
            fig.add_annotation(x=x[j], y=y[i], text=f"<b>{int(cm[i][j])}</b>", showarrow=False,
                               font=dict(size=26, color="white" if cm[i][j] > top / 2 else NAVY))
    fig.update_yaxes(autorange="reversed")
    return _style(fig, title, 340)


def roc_fig(fpr, tpr, auc: float, title: str = "ROC curve (test set)") -> go.Figure:
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=[0, 1], y=[0, 1], mode="lines", name="Chance",
                             line=dict(color=GREY, dash="dash")))
    fig.add_trace(go.Scatter(x=fpr, y=tpr, mode="lines", name=f"Model (AUC = {auc:.3f})",
                             line=dict(color=TEAL, width=3), fill="tozeroy",
                             fillcolor="rgba(15,163,163,0.10)"))
    fig.update_xaxes(title="False positive rate", range=[0, 1])
    fig.update_yaxes(title="True positive rate (recall)", range=[0, 1.02])
    return _style(fig, title, 340)


def importance_fig(coef_df: pd.DataFrame, top_n: int = 15,
                   title: str = "Global feature importance (standardized coefficients)") -> go.Figure:
    top = coef_df.head(top_n)
    order = top.sort_values("abs_importance")["feature"].tolist()   # smallest first -> largest on top
    fig = go.Figure()
    for name, mask, color in (
        ("Raises malignant probability", top["malignant_effect"] > 0, RED),
        ("Lowers malignant probability", top["malignant_effect"] <= 0, TEAL),
    ):
        sub = top[mask]
        fig.add_trace(go.Bar(x=sub["malignant_effect"], y=sub["feature"], orientation="h",
                             name=name, marker_color=color))
    fig.update_yaxes(categoryorder="array", categoryarray=order)
    fig.update_xaxes(title="Effect on malignant log-odds per 1 SD increase")
    return _style(fig, title, 120 + 26 * len(top))


def probability_gauge(p_malignant: float) -> go.Figure:
    pct = p_malignant * 100
    fig = go.Figure(
        go.Indicator(
            mode="gauge+number",
            value=pct,
            number=dict(suffix="%", valueformat=".1f", font=dict(color=NAVY, size=44)),
            title=dict(text="Model-estimated probability<br>of the malignant class", font=dict(size=14)),
            gauge=dict(
                axis=dict(range=[0, 100], ticksuffix="%"),
                bar=dict(color=NAVY, thickness=0.28),
                bgcolor="white",
                steps=[
                    dict(range=[0, MEDIUM_THRESHOLD * 100], color="#D7F0EF"),
                    dict(range=[MEDIUM_THRESHOLD * 100, HIGH_THRESHOLD * 100], color="#FBEBC8"),
                    dict(range=[HIGH_THRESHOLD * 100, 100], color="#F6D4D9"),
                ],
            ),
        )
    )
    fig.update_layout(height=300, margin=dict(l=30, r=30, t=70, b=10), paper_bgcolor="rgba(0,0,0,0)",
                      font=dict(family=FONT, color=NAVY))
    return fig


def contribution_fig(contrib: pd.DataFrame, top_n: int = 10,
                     title: str = "What drove this estimate? (top features)") -> go.Figure:
    top = contrib.head(top_n).sort_values("contribution")
    colors = [RED if v > 0 else TEAL for v in top["contribution"]]
    fig = go.Figure(
        go.Bar(x=top["contribution"], y=top["feature"], orientation="h", marker_color=colors,
               customdata=np.stack([top["value"], top["z_score"]], axis=-1),
               hovertemplate="%{y}<br>value: %{customdata[0]:.3f}<br>z-score: %{customdata[1]:.2f}"
                             "<br>contribution: %{x:.2f}<extra></extra>")
    )
    fig.update_xaxes(title="Contribution to malignant log-odds  (red = toward malignant, teal = toward benign)")
    return _style(fig, title, 120 + 30 * len(top))


def class_histogram(df: pd.DataFrame, feature: str, label_col: str = "diagnosis") -> go.Figure:
    fig = go.Figure()
    for label in ("Benign", "Malignant"):
        sub = df[df[label_col] == label]
        fig.add_trace(go.Histogram(x=sub[feature], name=label, opacity=0.65,
                                   marker_color=CLASS_COLORS[label], nbinsx=30))
    fig.update_layout(barmode="overlay")
    fig.update_xaxes(title=feature)
    fig.update_yaxes(title="Records")
    return _style(fig, f"Distribution of '{feature}' by class", 340)


def priority_bar(counts: dict[str, int], title: str = "Illustrative review-priority groups") -> go.Figure:
    vals = [int(counts.get(k, 0)) for k in PRIORITY_ORDER]
    fig = go.Figure(
        go.Bar(x=PRIORITY_ORDER, y=vals, marker_color=[PRIORITY_COLORS[k] for k in PRIORITY_ORDER],
               text=vals, textposition="outside")
    )
    fig.update_yaxes(title="Cases", range=[0, max(vals + [1]) * 1.18])
    return _style(fig, title, 340)


def probability_histogram(test_probs: pd.DataFrame,
                          title: str = "Predicted malignant probability on test records") -> go.Figure:
    fig = go.Figure()
    for label in ("Benign", "Malignant"):
        sub = test_probs[test_probs["actual"] == label]
        fig.add_trace(go.Histogram(x=sub["p_malignant"], name=f"Actual {label.lower()}", opacity=0.7,
                                   marker_color=CLASS_COLORS[label], xbins=dict(start=0, end=1, size=0.05)))
    fig.update_layout(barmode="overlay")
    fig.update_xaxes(title="Model-estimated P(malignant)", range=[0, 1])
    fig.update_yaxes(title="Test records")
    return _style(fig, title, 340)
